<?php

class test extends \PHPUnit_Framework_TestCase{
namespace project;
public class testThatWeCanGetTheFirstName()
{

$user = new \App\Models\User;

$user -> setFirstName('Billy');
$this->assertEquals($user->getFirstName(), 'Billy');    
}
}
