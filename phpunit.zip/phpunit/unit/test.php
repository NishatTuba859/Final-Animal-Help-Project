<?php

class test extends \PHPUnit_Framework_TestCase{
namespace project;
public class testThatWeCanGetTheFirstName()
{

$name = new \project\app;

$name -> setName('Billy');
$this->assertEquals($name->getName(), 'Billy');    
}
}
