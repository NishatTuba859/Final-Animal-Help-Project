<?php
    class SampleTest extends \PHPUnit\Framework\TestCase
    {
    public function testTrueAssertsToTrue()
    {
    $this->assertTrue(true);
    }
}